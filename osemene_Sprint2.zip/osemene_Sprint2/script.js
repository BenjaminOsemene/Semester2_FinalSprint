//I used dynamic javascript concepts to enhance my portfolio website.
//Added an "active" class to the navigation link which indicates page that is currently active.
document.addEventListener("DOMContentLoaded", function() {
    let curPage = window.location.pathname.split("/").pop(); 
    let links = document.querySelectorAll("nav a"); 
    
    links.forEach(function(link) {
      let linkPage = link.getAttribute("href").split("/").pop(); 
      
      if (linkPage === curPage) {
        link.classList.add("active"); 
      }
    });
  });
  

// Used DOM manipulation, ensures that when the form data is being correctly entered,
//It is  being captured and submitted with success message shown.
// Finally logging to the console to see the data and resetting the form.

document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    contactForm.addEventListener('submit', function(event) {
      event.preventDefault();
  
      const formData = new FormData(contactForm);
      const name = formData.get('name');
      const email = formData.get('email');
      const message = formData.get('message');
  
      
      contactForm.reset();
  
    const successMessage = document.getElementById('successMessage');
    successMessage.textContent = 'Thank you! Your message has been sent successfully.';
    successMessage.style.display = 'block';
    successMessage.style.color = 'green'; // Set color to green
    successMessage.style.fontWeight = 'bold'; // Set font weight to bold
 });
});
  
  
// Also I used JavaScript for email validation
//When the user enters  email in the form, it checks using the provided regular expression.
// incomplete error message shown if regular expression does not match with email and form not submitted.

document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    const errorMessage = document.getElementById('errorMessage');
  
    contactForm.addEventListener('submit', function(event) {
      event.preventDefault(); 
  
      const emailInput = document.getElementById('email');
      const email = emailInput.value.trim();
      if (!validateEmail(email)) {
        errorMessage.textContent = 'Invalid email address';
        errorMessage.style.display = 'block';

        return;
      }
  
      this.submit();
    });
  
    function validateEmail(email) {
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return regex.test(email);
    }
  });


//Implemented reset button that clears the fields in the form when the user wants to start all over.
  document.addEventListener('DOMContentLoaded', function() {
    const resetButton = document.getElementById('resetForm');
    resetButton.addEventListener('click', function() {
        const form = document.getElementById('contactForm');
        form.reset();
    });
});



//Implemented button for changing the background color of the portfolio website anytime the user clicks
// By generating random hex colors
document.getElementById('changeColorButton').addEventListener('click', function() {
    changeBackgroundColor();
  });
  
  function changeBackgroundColor() {
    var randomColor = '#' + Math.floor(Math.random()*16777215).toString(16); 
    document.body.style.backgroundColor = randomColor;
  }
  




  